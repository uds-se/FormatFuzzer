$password = "bitc@1234" | ConvertTo-SecureString -asPlainText -Force
$username = "pratest\komali"
[PSCredential] $credential = New-Object System.Management.Automation.PSCredential($username,$password)

Configuration DomainCredentialExample
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    node prawintest
    {
        Group addUsers {
            GroupName = 'Users'
            Ensure = 'Present'
            MembersToInclude = 'pratest\test1'
            Credential       = $credential
        }
    }
}

$cd = @{
    AllNodes = @(
        @{
            NodeName = 'prawintest'
            PSDscAllowDomainUser = $true
            PSDscAllowPlainTextPassword = $true
        }
    )
}

DomainCredentialExample -ConfigurationData $cd
