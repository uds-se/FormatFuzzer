<?php
  
 $iname = $_POST['iname'];
 $position = $_POST['position'];
 $dointerview = $_POST['dointerview'];
 $cname = $_POST['cname'];
 $comabilities = $_POST['comabilities'];
 $compskills = $_POST['compskills'];
 $comment = $_POST['comment'];

 if (!empty($iname)) || !empty($position) || !empty($dointerview) || !empty($cname) || !empty($comabilities) || !empty($compskills) || !empty($comment) {
        $host = "localhost";
        $dbname = "machineproblem6"; 

        //connection
        $conn = new mysqli($host,$dbname);

        if (mysqli_connect_error()) {
          die('Connect Error('.mysql_connect_errno().')'.mysqli_connect_error());
        } else {
          $INSERT = "INSERT Into machineproblem6 (iname, position, dointerview, cname, comabilities, compskills, comment)
          values (?,?,?,?,?,?,?)"

          $conn -> close();
        }
 } else {
      echo "All field are required";
      die();
 }

?>