
public class ShootingRound {

	
	int numHits;
	
	public ShootingRound(int numHits)	
	{
		this.numHits = numHits;
	}
	
	int getNumHits()
	{
		return numHits;
	}
}
